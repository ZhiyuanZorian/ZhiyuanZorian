function [azimuth, elevation] = xyzazel(target_x, target_y, target_z)
    % 计算方位角
    azimuth = atan2(target_y, target_x);

    % 计算高度角
    elevation = atan2(target_z, sqrt(target_x^2 + target_y^2));

    % 将方位角和高度角转换为度数
    azimuth = rad2deg(azimuth);
    elevation = rad2deg(elevation);

    % 确保方位角在 [0, 360) 范围内
    azimuth = mod(azimuth, 360);
end
