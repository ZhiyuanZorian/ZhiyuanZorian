%% create a serie of struct to store data
clear all; close all;
GM=398600500000000;
eps=0.00001;
omegaE=2*pi/86164;
siderealtime=2*pi*(3*60*60)/(24*3600);
r_wettzell=[4075530.22;931781.30;4801618.19]; %unit (m)
x1=r_wettzell(1,1);y1=r_wettzell(2,1);z1=r_wettzell(3,1);
beta=atan2(y1,x1);alpha=(pi/2)-atan(z1/sqrt(x1*x1+y1*y1));
Q1=[-1,0,0;0,1,0;0,0,1];
%S(1)=GOCE
s(1).a=6629000; s(1).e=0.004; s(1).i=96.6*2*pi/360; s(1).o=210*2*pi/360;
s(1).w=144*2*pi/360;s(1).T0=1;
%s(2)=GPS
s(2).a=26560000; s(2).e=0.01; s(2).i=55*2*pi/360; s(2).o=30*2*pi/360;
s(2).w=30*2*pi/360;s(2).T0=11;
%s(3)=Molniya
s(3).a=26554000; s(3).e=0.7; s(3).i=63*2*pi/360; s(3).o=200*2*pi/360;
s(3).w=270*2*pi/360;s(3).T0=5;
%s(4)=GEO
s(4).a=42164000; s(4).e=0; s(4).i=0*2*pi/360; s(4).o=0*2*pi/360;
s(4).w=50*2*pi/360;s(4).T0=0;
%s(5)=Michibiki
s(5).a=42164000; s(5).e=0.075; s(5).i=41*2*pi/360; s(5).o=200*2*pi/360;
s(5).w=270*2*pi/360;s(5).T0=19;
%% Task1: orbits in 2D plane
%t=60; %t as the input
ts=[51,83,53,24,131]; 
%ts=[24,50,50,72,91]; 
for j=1:5
    t=ts(1,j);
    s(j).n=sqrt(GM/(s(j).a*s(j).a*s(j).a)); %calculate each n
    s(j).period=2*pi/(s(j).n);
    s(j).period=s(j).period/3600;
    s(j).interval=t-s(j).T0;
    s(j).M=s(j).n*s(j).interval*3600; %unit of interval should be s
    s(j).matrix=zeros(7,s(j).interval*60); %value matrix for satellites
    s(j).rmatrix=zeros(3,s(j).interval*60); % rmatrix to describe vector r
    s(j).theta0=zeros(1,s(j).interval*60);
    %s(j).r3matrix=zeros(3,s(j).interval*60);
    s(j).latiandlongti=zeros(2,s(j).interval*60);
    s(j).rdotmatrix=zeros(3,s(j).interval*60); %rdotmatrix to describe vector rdot
    number=s(j).interval*60;
    ecc=s(j).e;
    i0=s(j).i*(-1); o0=s(j).o*(-1); w0=s(j).w*(-1);
    s(j).imatrix=[1,0,0;0,cos(i0),sin(i0);0,(-1)*sin(i0),cos(i0)];   %R1(-i)
    s(j).omatrix=[cos(o0),sin(o0),0;(-1)*sin(o0),cos(o0),0;0,0,1];   %R3(-o)
    s(j).wmatrix=[cos(w0),sin(w0),0;(-1)*sin(w0),cos(w0),0;0,0,1];   %R3(-w) 
    for i=1:number
       s(j).matrix(1,i)=i*60;  %unit second
       s(j).matrix(2,i)=s(j).n*s(j).matrix(1,i); % M at each t
       E=s(j).matrix(2,i);   %fisrt value of E at each time.
       M0=E;  
       for k=1:100  %itineration of E at each t
           dE=(M0-E+ecc*sin(E))./(1-ecc*cos(E));
           if(max(abs(dE))<eps)
               break
           end
           E=E+dE;
       end
       s(j).matrix(3,i)=E; %E at each time is calculated.
       s(j).matrix(4,i)=s(j).a*(1-ecc*cos(E)); % r at each time.
       r_temporal=s(j).matrix(4,i);
       s(j).matrix(5,i)=2*atan(tan(E/2)*sqrt((1+ecc)/(1-ecc))); %v at each time
       v_temporal=s(j).matrix(5,i);
       s(j).rmatrix(1,i)=r_temporal*cos(v_temporal);           %vector r line 1
       s(j).rmatrix(2,i)=r_temporal*sin(v_temporal);           %vector r line 2
       s(j).rdotmatrix(1,i)=r_temporal*sin(v_temporal)*(-1);           %vector rdot line 1
       s(j).rdotmatrix(2,i)=r_temporal*(cos(v_temporal)+ecc);          %vector rdot line 2
       s(j).matrix(6,i)=r_temporal*cos(v_temporal); %x at eachtime
       s(j).matrix(7,i)=r_temporal*sin(v_temporal); %y at eachtime
       s(j).r_equator(:,i)=s(j).omatrix*s(j).imatrix*s(j).wmatrix*s(j).rmatrix(:,i);
       %s(j).theta0(1,i)=omegaE*i*60+siderealtime;   %theta0
       s(j).theta0(1,i)=omegaE*i*60+omegaE*s(j).T0*3600+siderealtime;   %theta0
       theta=s(j).theta0(1,i);
       thetamatrix=[cos(theta),sin(theta),0;(-1)*sin(theta),cos(theta),0;0,0,1];  %R3(theta0)
       s(j).r3matrix(:,i)=thetamatrix*s(j).r_equator(:,i);    %r3=R3(theta0(t))*r2
       s(j).rtransmatrix(:,i)=s(j).r3matrix(:,i)-r_wettzell;  %rtrans=r3-r_wettzell
       x3=s(j).r3matrix(1,i);y3=s(j).r3matrix(2,i);z3=s(j).r3matrix(3,i);  %the vector of r3
       %s(j).latiandlongti(1,i)=00+360*atan2(y3,x3)/(2*pi); %longitude
       %s(j).latiandlongti(2,i)=360*atan(z3/sqrt(x3*x3+y3*y3))/(2*pi); %laditude
       [latitude, longitude, height] = xyzblh(x3, y3, z3);
       s(j).latiandlongti(1,i) = longitude; s(j).latiandlongti(2,i) = latitude; %longitude and latitude of r3
       xtrans=s(j).rtransmatrix(1,i);ytrans=s(j).rtransmatrix(2,i);ztrans=s(j).rtransmatrix(3,i);  %the vector of rtrans
       [latitude, longitude, height] = xyzblh(xtrans, ytrans, ztrans);
       s(j).translatiandlongti(1,i) = longitude; s(j).translatiandlongti(2,i) = latitude;
       %s(j).translatiandlongti(1,i)=360*atan2(ytrans,xtrans)/(2*pi); %longitude of rtrans
       %s(j).translatiandlongti(2,i)=360*atan(ztrans/sqrt(xtrans*xtrans+ytrans*ytrans))/(2*pi); %laditude of rtrans
       R2=[cos(alpha),0,(-1)*sin(alpha);0,1,0;sin(alpha),0,cos(alpha)];
       R3=[cos(beta),sin(beta),0;(-1)*sin(beta),cos(beta),0;0,0,1];
       s(j).r4matrix(:,i)=Q1*R2*R3*s(j).rtransmatrix(:,i); %calculation of r4
       x4=s(j).r4matrix(1,i);y4=s(j).r4matrix(2,i);z4=s(j).r4matrix(3,i);  %the vector of r4
       [azimuth, elevation] = xyzazel(x4, y4, z4);
       s(j).r4latiandlongti(1,i) = azimuth; s(j).r4latiandlongti(2,i) = elevation;   %azimuth and elevation from r4
       %s(j).r4latiandlongti(1,i)=360*atan2(y4,x4)/(2*pi); %azimuth from r4
       %s(j).r4latiandlongti(2,i)=360*atan(z4/sqrt(x4*x4+y4*y4))/(2*pi); %elevation from r4
       if s(j).r4latiandlongti(2,i)<0
           s(j).r4latiandlongti(3,i) = NaN;
           s(j).r4latiandlongti(4,i) = 0;  %visuality
       else
           s(j).r4latiandlongti(3,i) = s(j).r4latiandlongti(2,i);
           s(j).r4latiandlongti(4,i) = 1;  %visuality
       end
       
    end
    s(j).rdotmatrix = s(j).rdotmatrix*sqrt(GM/(s(j).a*(1-ecc*ecc)));
    s(j).r_equator=s(j).omatrix*s(j).imatrix*s(j).wmatrix*s(j).rmatrix;       %position
    s(j).rdot_equator=s(j).omatrix*s(j).imatrix*s(j).wmatrix*s(j).rdotmatrix; %velocity 
    %resultr3(j).matrix=s(j).r3matrix;
    
end

%% Result presentation
figure (1)
axis equal
h1=skyplot(s(1).r4latiandlongti(1,:)',s(1).r4latiandlongti(2,:)','b.-')
hold on;
h2=skyplot(s(2).r4latiandlongti(1,:)',s(2).r4latiandlongti(2,:)','k.-')
hold on;
h3=skyplot(s(3).r4latiandlongti(1,:)',s(3).r4latiandlongti(2,:)','r.-')
hold on;
h4=skyplot(s(4).r4latiandlongti(1,:)',s(4).r4latiandlongti(2,:)','c*')
hold on;
h5=skyplot(s(5).r4latiandlongti(1,:)',s(5).r4latiandlongti(2,:)','m.-')
hold on;
legend([h1,h2,h3,h4,h5],'GOCE','GPS','Molniya','GEO','Michibiki')
title('Topo-centric track of 5 sateltiles')
figure (2)
axis equal
h1=skyplot(s(1).r4latiandlongti(1,:)',s(1).r4latiandlongti(3,:)','b.-')
hold on;
h2=skyplot(s(2).r4latiandlongti(1,:)',s(2).r4latiandlongti(3,:)','k.-')
hold on;
h3=skyplot(s(3).r4latiandlongti(1,:)',s(3).r4latiandlongti(3,:)','r.-')
hold on;
h4=skyplot(s(4).r4latiandlongti(1,:)',s(4).r4latiandlongti(3,:)','c*')
hold on;
h5=skyplot(s(5).r4latiandlongti(1,:)',s(5).r4latiandlongti(3,:)','m.-')
hold on;
legend([h1,h2,h3,h4,h5],'GOCE','GPS','Molniya','GEO','Michibiki')
title('Topo-centric track of 5 sateltiles (ele<0 = NaN)')

%% visuality
figure (3)
subplot(5,1,1)
area(s(1).matrix(1, :)/3600, s(1).r4latiandlongti(4, :), 'FaceColor', 'g', 'EdgeColor', 'g');
title('GOCE');
%xlim([s(1).T0 s(1).T0+24]);
%xticks(s(1).T0:2:s(1).T0+24);
xlim([0 24]);
xticks(0:2:24);
xlabel('Time [hour]');
ylabel('Visibility');

subplot(5,1,2)
area(s(2).matrix(1, :)/3600, s(2).r4latiandlongti(4, :), 'FaceColor', 'r', 'EdgeColor', 'r');
title('GPS');
xlim([s(2).T0 s(2).T0+24]);
xticks(s(2).T0:2:s(2).T0+24);
xlabel('Time [hour]');
ylabel('Visibility');

subplot(5,1,3)
area(s(3).matrix(1, :)/3600, s(3).r4latiandlongti(4, :), 'FaceColor', 'b', 'EdgeColor', 'b');
title('MOLYNIA');
xlim([s(3).T0 s(3).T0+24]);
xticks(s(3).T0:2:s(3).T0+24);
xlabel('Time [hour]');
ylabel('Visibility');

subplot(5,1,4)
area(s(4).matrix(1, :)/3600, s(4).r4latiandlongti(4, :), 'FaceColor', 'k', 'EdgeColor', 'k');
title('GEO');
xlim([s(4).T0 s(4).T0+24]);
xticks(s(4).T0:2:s(4).T0+24);
xlabel('Time [hour]');
ylabel('Visibility');

subplot(5,1,5)
area(s(5).matrix(1, :)/3600, s(5).r4latiandlongti(4, :), 'FaceColor', 'c', 'EdgeColor', 'c');
title('MICHIBIKI');
xlim([s(5).T0 s(5).T0+24]);
xticks(s(5).T0:2:s(5).T0+24);
xlabel('Time [hour]');
ylabel('Visibility');


